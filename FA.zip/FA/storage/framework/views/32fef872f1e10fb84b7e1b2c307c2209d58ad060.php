<?php $__env->startSection('content'); ?>
<script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
<script type="text/javascript">


$(document).ready(function () {
    
	$('.test tbody').on('click', '.gunakan', function() {
		const n = $(this).data('diskon');
		const jumlah = $('#gt').val().replace(/[,.]/g, '');
		
		console.log(jumlah);
		
		
		const diskon = jumlah * (n / 100);
		const totalnet = jumlah - diskon;
		
		$('#gt1').val(n);
		$('#gtnet').val(formatMoney(totalnet));
		
		
		
		$('#exampleModalLong').modal('hide');
		
	});
	
	
});


	function TotalHarga()
	{

		var T_HARGA = 0;

		   var i;
           for (i = 0; i <=100; i++) {			

			var harga = $("#harga_"+i).val() || 0;

            var total_harga = $("#total_harga_"+i).val() || 0;

			var qty = $("#qty_"+i).val() || 0;

			var total_harga = parseFloat(harga) * parseFloat(qty);

			$("#total_harga_"+i).val(formatMoney(total_harga));

      T_HARGA +=  total_harga;

			}
      $("#gt").text(T_HARGA);

      $("#bayar").val(T_HARGA);
	  $("#gt").val(formatMoney(T_HARGA));
	}

/*iini js nya*/
function myFunction() {
	var i;
	for (i = 0; i <=100; i++) {
	var t = $("#test_"+i).val();
	$("#field2").val(t);
	
	}
}

function formatMoney(amount, decimalCount = 0, decimal = ",", thousands = ".") {
    try {
        decimalCount = Math.abs(decimalCount);
        decimalCount = isNaN(decimalCount) ? 2 : decimalCount;

        const negativeSign = amount < 0 ? "-" : "";

        let i = parseInt(amount = Math.abs(Number(amount) || 0).toFixed(decimalCount)).toString();
        let j = (i.length > 3) ? i.length % 3 : 0;

        return negativeSign + (j ? i.substr(0, j) + thousands : '') + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousands) + (decimalCount ? decimal + Math.abs(amount - i).toFixed(decimalCount).slice(2) : "");
    } catch (e) {
        console.log(e)
    }
};

function formatRupiah(angka, prefix) {
    var number_string = angka.replace(/[^,\d]/g, '').toString(),
        split = number_string.split(','),
        sisa = split[0].length % 3,
        rupiah = split[0].substr(0, sisa),
        ribuan = split[0].substr(sisa).match(/\d{3}/gi);

    if (ribuan) {
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
    }

    rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
    return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
}
	</script>

<div class="bg-light py-3">
    <div class="container">
    <div class="row">
        <div class="col-md-12 mb-0"><a href="index.html">Home</a> <span class="mx-2 mb-0">/</span> <strong class="text-black">Cart</strong></div>
    </div>
    </div>
</div>

<div class="site-section">
    <div class="container">
    <div class="row mb-5">
        <form class="col-md-12" method="post" action="<?php echo e(route('user.keranjang.update')); ?>">
        <?php echo csrf_field(); ?>
            <table class="table table-bordered" id="data_table_barang">
            <thead>
                <tr>
               
                <th class="product-name">PRODUK</th>
                <th class="product-price">PILIHAN HARGA</th>
                <th class="product-quantity">KUANTITAS</th>
                <th class="product-total">SUBTOTAL</th>
                <th class="product-remove">HAPUS</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    
                <?php 
				$i=0;
				$subtotal=0; 
				foreach($keranjangs as $keranjang): $i++;?>
               
                <td class="product-name">
                     <img src="<?php echo e(asset('storage/'.$keranjang->image)); ?>" alt="Image" class="img-fluid" width="100"><h1 class="h5 text-black"><?php echo e($keranjang->nama_produk); ?></h1>
                </td>
                <td>
				<input type="hidden" id="harga_<?=$i;?>" value="<?php echo e($keranjang->price); ?>">
				<input type="text" id="price_<?=$i;?>" value="<?php echo e(number_format($keranjang->price,0,',','.')); ?>" readonly></td>
                <td>
                    <div class="input-group mb-3" style="max-width: 80px;">
                    <input type="hidden" name="id[]" value="<?php echo e($keranjang->id); ?>">
                    <input type="number" id="qty_<?=$i;?>"name="qty[]" class="form-control text-left" onchange="TotalHarga()" placeholder="" aria-label="Example text with button addon" aria-describedby="button-addon1" value="<?php echo e($keranjang->qty); ?>">
                   
                    </div>

                </td>
                <?php
                    $total = $keranjang->price * $keranjang->qty;
                    $subtotal = $subtotal + $total;
                ?>
                <td><input type="text" id="total_harga_<?=$i;?>" value="<?php echo e(number_format($total,0,',','.')); ?>" readonly></td>
                <td><a href="<?php echo e(route('user.keranjang.delete',['id' => $keranjang->id])); ?>" class="btn btn-primary btn-sm">X</a></td>
                </tr>
		
                <?php 
				
				
				endforeach;?>
            </tbody>
            </table>
        
    </div>

    <div class="row">
        <div class="col-md-6">
        <div class="row mb-5">
            <div class="col-md-6 mb-3 mb-md-0">
            <button type="submit" class="btn btn-primary btn-sm btn-block">Update Keranjang</button>
            </div>
            </form>       
        </div>
        </div>
        <div class="col-md-6 pl-5">
        <div class="row justify-content-end">
            <div class="col-md-7">
            <div class="row">
                <div class="col-md-12 text-right border-bottom mb-5">
				<a href="#" data-toggle="modal" data-target="#exampleModalLong">
				<img src="https://img.floweradvisor.com/images/discount-ico.png" width="20px">
				<span class="text"> Gunakan Kode Diskon/Reward</span></a>
                <h3 class="text-black h4 text-uppercase">Total Belanja</h3>
                </div>
            </div>
            <div class="row mb-5">
                <div class="col-md-6">
                <span class="text-black">Total</span>
				<span class="text-black">Total</span>
                </div>
                <div class="col-md-6 text-right">
                <strong class="text-black"><input type="text" class="form-control font-weight-bold" id="gt" 
		name="grandtotalbarang" value="<?php echo e(number_format($subtotal,0,',','.')); ?>" readonly></strong>
		<strong class="text-black"><input type="text" class="form-control font-weight-bold" id="gt1" 
		name="disc"></strong>
		<strong class="text-black"><input type="text" class="form-control font-weight-bold" id="gtnet" 
		name="disc"></strong>
                </div>
            </div>

            <div class="row">
                <?php if($cekalamat > 0): ?>
                <div class="col-md-12">
                <a href="<?php echo e(route('user.checkout')); ?>" class="btn btn-primary btn-lg py-3 btn-block" >Checkout</a>
                <small>Jika Merubah Quantity Pada Keranjang Maka Klik Update Keranjang Dulu Sebelum Melakukan Checkout</small>
                </div>
                <?php else: ?>
                <div class="col-md-12">
                <a href="<?php echo e(route('user.alamat')); ?>" class="btn btn-primary btn-lg py-3 btn-block" >Atur Alamat</a>
                <small>Anda Belum Mengatur Alamat</small>
                </div>
                <?php endif; ?>
            </div>
            </div>
        </div>
        </div>
    </div>
	
	<div class="clear"></div>
	
	<div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
        </br>
	</br>
	  </br>
	</br>
	  </br>
	</br>
		<div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Modal title<p id="demo"></p>
</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
               <table class="table table-bordered test" id="data_table_barang">
            <thead>
                <tr>
               
                <th class="product-name">VOUCHER</th>
                <th class="product-price">GUNAKAN</th>
               
                </tr>
            </thead>
            <tbody>
			<?php 
			$n=0;
			foreach($diskons as $diskon) : $i++;?>
			 
                <tr>
						<input type="hidden" id="test_<?=$n;?>" value="<?php echo e($diskon->kode_voucher); ?>">
						<td><?php echo e($diskon->nama_voucher); ?> % <br> Kode Voucher <?php echo e($diskon->kode_voucher); ?> </td>
						<td> <button type="button" class="btn btn-danger gunakan" data-diskon="<?= $diskon->diskon_voucher_persen;?>">Gunakan</button></td>
				</tr>
				<?php endforeach;?>
				
			</tbody>
			</table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              
            </div>
            </div>
        </div>
        </div>
		
    </div>
	 
</div>



      
        <!-- Modal -->
		
		
       
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel8n\resources\views/user/keranjang.blade.php ENDPATH**/ ?>